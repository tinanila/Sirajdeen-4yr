import { Component, Output , EventEmitter} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Nila_Apps_Assessment';

  isSidebarActive = false;
  @Output() search: EventEmitter<any> = new EventEmitter();

  onToggleSidebar(isActive: boolean) {
    this.isSidebarActive = isActive; // Update the state based on emitted value
  }

  getNotification(evt:any) {
  this.search.emit(evt);
}

  
}
