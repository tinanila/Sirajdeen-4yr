import { Component,Input } from '@angular/core';
import { Output, EventEmitter } from '@angular/core';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { EventService } from '../dashboard/services/event.service';



@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent {
  selectedValue = 'Chennai';
  isSearchbar = false
  searchValue : any;
  @Input() isSidebarActive: boolean = false; // Default to false
  @Output() search: EventEmitter<any> = new EventEmitter();

  options = [
    { value: 'Chennai', viewValue: 'Chennai' },
    { value: 'Madurai', viewValue: 'Madurai' }
  ];

  constructor(private eventService: EventService, public dashboard : DashboardComponent) { }

  ngOnInit(): void { 
  }

  openSeachbar(val:any){
    this.isSearchbar = (val == 'open') ? true : false
  }

  searchKey(value:any){
    this.dashboard.searchValue(this.searchValue)
  }

  
}
