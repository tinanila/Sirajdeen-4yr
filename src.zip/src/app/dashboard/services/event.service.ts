import { Injectable, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  public navItemSelected: EventEmitter<string> = new EventEmitter<string>();

  emitNavItemSelected(item: string) {
    this.navItemSelected.emit(item);
  }
}
