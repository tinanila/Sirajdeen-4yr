import { Component, inject, Input, OnInit, Optional, Injectable } from '@angular/core';
import { Route, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { EventService } from './services/event.service';


@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  buttonId = 0

  selectedItem: string | undefined;
  public subscription: Subscription | undefined;
  filteritems : any;

  @Input() search = ''; // decorate the property with @Input()

  buttons = [
    {id:0, title:'All'},
    {id:1, title:'PEO-1',des:'Employability',icon:'description'},
    {id:2, title:'PEO-2',des:'Entrepreneur',icon:'description'},
    {id:3, title:'PEO-3',des:'Research & Development ',icon:'description'},
    {id:4, title:'PEO-4',des:'Contribution to business ',icon:'description'},
    {id:5, title:'PEO-4',des:'Contribution to society',icon:'description'},

  ]
  items = [
    { id: 1, title: 'Decision Making Skill', progress:60,content: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s',code:'PO1', bgColor:'#2471a3' },
    { id: 2, title: 'Communication Skill', progress:60,content: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s',code:'PO2', bgColor:'#2471a3' },
    { id: 3, title: 'Employability Skill',  progress:60,content: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s',code:'PO3', bgColor:'#2471a3' },
    { id: 4, title: 'Entrepreneurial Skill',  progress:60,content: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s',code:'PO4', bgColor:'#2471a3' },
    { id: 5, title: 'Contribution to Society',  progress:60,content: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s' ,code:'PO5', bgColor:'#2471a3'},
    { id: 6, title: 'Problem Solving skill',  progress:60,content: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s',code:'PO5', bgColor:'#2471a3' },
  ];

  originalItems : any 
  filteredItem:any
  constructor(private router : Router, private eventService: EventService) { 

    console.log(this.search);
    
  }

  ngOnInit() {
    
  }

  buttonClick(val:any){
    console.log(val);
    this.buttonId = val
    
  }

  searchValue(val:any){

    this.originalItems = [...this.items];

  
      const lowerVal = val.toLowerCase();
      const filteredItems = this.originalItems.filter((item: { title: string; }) => item.title.toLowerCase().includes(lowerVal));
      var items = filteredItems.length ? filteredItems : this.originalItems;
    
  
    this.filteredItem = items
      
    console.log(this.filteredItem );
    console.log(this.filteredItem.length);
    
    
  }


  


  applyFilter(filterValue: string) {
  
  }

outComeRouting(){
  this.router.navigate(['program_outcome'])
}
}
