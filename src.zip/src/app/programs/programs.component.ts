import { Component, OnInit } from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatSort} from '@angular/material/sort'


export interface PeriodicElement {
  program_code: string;
  program_name: string;
  program_attainment: Number;
  program_status : string
}

@Component({
  selector: 'app-programs',
  templateUrl: './programs.component.html',
  styleUrls: ['./programs.component.scss']
})
export class ProgramsComponent implements OnInit {

  selected: boolean = false;
  displayedColumns: string[] = ['program_code', 'program_name', 'program_attainment', 'program_status'];
  dataSource : any;

  tableData =  [
    {
      program_code : 'MVO12H',
      program_name: 'Master in Businessn Administration',
      program_attainment:70,
      program_status:'Live'
    },
    {
    program_code : 'MVO13I',
    program_name: 'Master in Businessn Administration',
    program_attainment:70,
    program_status:'Live'
    },
    {
      program_code : 'MVO12M',
      program_name: 'Master in Businessn Administration',
      program_attainment:70,
      program_status:'Live'
    },
    {
      program_code : 'MV134S',
      program_name: 'Master in Businessn Administration',
      program_attainment:70,
      program_status:'Live'
    },
    {
    program_code : 'MVO133R',
    program_name: 'Master in Businessn Administration',
    program_attainment:70,
    program_status:'Live'
    },
    {
      program_code : 'MVO13I',
      program_name: 'Master in Businessn Administration',
      program_attainment:70,
      program_status:'draft'
    },
  ]
  constructor() { }

  ngOnInit(): void {

    this.dataSource = new MatTableDataSource(this.tableData);
  }
}
